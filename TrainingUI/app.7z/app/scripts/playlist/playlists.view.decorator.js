(function () {
  'use strict';
  angular
    .module('songApp')
    .factory('PlaylistViewService', ['PlayListFactory', 'CommonService',
      'commonConstant', 'PlaylistCreateService', 'PlaylistEditService',
      function (PlayListFactory, commonService, commonConstant, PlaylistCreateService, PlaylistEditService) {

        var injectedVm;

        function decorate(vm) {
          injectedVm = vm;
          injectedVm.cache = PlayListFactory.cache;
          injectedVm.initViewPage = initViewPage;
        }

        function initViewPage() {
          initService();
          loadPlaylist();
        }

        function initService() {

          injectedVm.showPlaylistView = {
            playlists: [],
            searchText: {text: ''},// set the default search/filter
            isCheckedHeaderChkbox: {status: false},
            isDisabledDeleteBtn: {status: true},
            function: {
              isShowMode: isShowMode,
              switchAddMode: switchAddMode,
              removeByIndex: removeByIndex,
              deletePlayLists: deletePlayLists,
              loadPlaylist: loadPlaylist// user for create and edit reload playlist
            }
          };

          injectedVm.configDataPlaylistTable = {
            items: [],
            titleColumns: ['app.table.playlist.id',
              'app.table.playlist.name',
              'app.table.playlist.description',
              'app.table.playlist.action'],
            isCheckedHeaderChkbox: injectedVm.showPlaylistView.isCheckedHeaderChkbox,
            disableCheckedAll: injectedVm.showPlaylistView.isDisabledDeleteBtn,
            listCheckedChkBox: injectedVm.cache.showPlaylistView.listCheckedChkBox,
            searchText: injectedVm.showPlaylistView.searchText
          };

          injectedVm.configFuncPlaylistTable = {
            formatData: PlayListFactory.function.formatRowTableData,
            onDirectToEditPage: switchEditMode,
            onRemoveItemByIndex: removeByIndex
          };


          var columns = [
            {
              name: 'Column 1',
              value: 'column1',
              binding: "r.column3 + \" / \" + r.column4",
              style: {},
              isWatched: true,
              isAnchor: false,
              isComputed: true,
              srefBinding: 'state expression here'
            },
            {name: 'Column 2', value: 'column2', binding: 'column2', isWatched: true, style: {}},
            {name: 'Column 3', value: 'column3', binding: 'column3', isWatechhed: true, style: {}},
            {name: 'Column 4', value: 'column4', binding: 'column4', isWatched: true, style: {}},
            {name: 'Column 5', value: 'column5', binding: 'column5', style: {}},
            {name: 'Column 6', value: 'column6', binding: 'column6', filter: "currency", isWatched: true, style: {}},
            {name: 'Column 7', value: 'column7', binding: 'column7', style: {}},
            {name: 'Column 8', value: 'column8', binding: 'column8', filter: "date:\"MM/dd/yyyy\"", style: {}}
          ];


          columns = [
            {
              display: 'Column 1', //The text to display
              variable: 'Name', //The name of the key that's apart of the data array
              filter: 'text' //The type data type of the column (number, text, date, etc.)
            },
            {
              display: 'Column 2', //The text to display
              variable: 'Amount', //The name of the key that's apart of the data array
              filter: 'number : 0' //The type data type of the column (number, text, date, etc.)
            },
            {
              display: 'Column 3', //The text to display
              variable: 'Date', //The name of the key that's apart of the data array
              filter: 'dateTime' //The type data type of the column (number, text, date, etc.)
            }
          ];

          columns = [
            {//Cols 1
              mapdata: 'id',
              colname: 'ID',
              styles: {},// style css or .class
            },
            {//Cols 2
              mapdata: 'name',
              colname: 'Name',
              styles: {},
            },
            {//Cols 3
              mapdata: 'description',
              colname: 'Description',
              styles: {},
            },
            {//Cols 3
              mapdata: 'action',
              colname: '',
              styles: {},
            }
          ];


        }

        function switchAddMode() {
          PlayListFactory.function.switchAddMode();
          PlaylistCreateService.decorate(injectedVm);
        }

        function isShowMode() {
          return injectedVm.cache.currentView.name === commonConstant.VIEW_MODE.SHOW;
        }

        /*** SWITCH EDIT PAGE ***/
        function switchEditMode(selectedPlaylist) {

          injectedVm.cache.common.playlistModel = selectedPlaylist;
          injectedVm.cache.editPlaylistView.currentPlaylist = angular.copy(selectedPlaylist);
          injectedVm.cache.currentView = PlayListFactory.views.edit;
          injectedVm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
          injectedVm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = true;
          injectedVm.cache.common.isDisabledCreateOrApplyBtn.status = true;
          PlaylistEditService.decorate(injectedVm);

        }

        function loadPlaylist() {
          commonService.getData(commonConstant.API.PLAYLIST).then(function (reponse) {
            injectedVm.showPlaylistView.playlists.length = 0;
            injectedVm.showPlaylistView.playlists.push(reponse.data);
            injectedVm.configDataPlaylistTable.items = angular.copy(reponse.data);// bo cho nay
            if (isShowMode()) {
              setCheckBoxsModelPlaylist();
            }
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              injectedVm.loadingState = false;
            }
          );
        }

        /*** Dua vao Table-view ***/
        function setCheckBoxsModelPlaylist() {
          var listCheckBoxPlaylist = injectedVm.cache.showPlaylistView.listCheckedChkBox;
          if (listCheckBoxPlaylist.length > 0) {
            for (var index = injectedVm.showPlaylistView.playlists.length; index--;) {
              var playlist = injectedVm.showPlaylistView.playlists[index];
              if (listCheckBoxPlaylist.indexOf(playlist.id) > -1) {
                playlist.isChecked = true;
              }
            }// end for
            if (listCheckBoxPlaylist.length === injectedVm.showPlaylistView.playlists.length) {
              injectedVm.showPlaylistView.isCheckedHeaderChkbox.status = true;
            }
            injectedVm.showPlaylistView.isDisabledDeleteBtn.status = false;
          }
        }

        /******* delete ********/
        function removeByIndex(index) {
          var playlist = {id: [injectedVm.showPlaylistView.playlists[index]]};//fix
          commonService.deleteData(commonConstant.API.PLAYLIST, playlist).then(function () {
            loadPlaylist();//reload playlist table after delete element
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
            }
          );
        }

        function deletePlayLists() {
          if (injectedVm.showPlaylistView.isCheckedHeaderChkbox.status) {
            injectedVm.showPlaylistView.playlists.length = 0;
            injectedVm.showPlaylistView.isCheckedHeaderChkbox.status = false;
            injectedVm.showPlaylistView.isDisabledDeleteBtn.status = true;
          }
          else {
            if (injectedVm.cache.showPlaylistView.listCheckedChkBox.length === injectedVm.showPlaylistView.playlists.length) {
              injectedVm.showPlaylistView.isCheckedHeaderChkbox.status = false;
            }
            deletePlayListOf(injectedVm.cache.showPlaylistView.listCheckedChkBox);
            injectedVm.cache.showPlaylistView.listCheckedChkBox.length = 0;
            injectedVm.showPlaylistView.isDisabledDeleteBtn.status = true;
          }
        }

        function deletePlayListOf(lstSongId) {
          for (var index = lstSongId.length; index--;) {
            for (var indexSong = injectedVm.showPlaylistView.playlists.length; indexSong--;) {
              if (lstSongId[index] === injectedVm.showPlaylistView.playlists[indexSong].id) {
                injectedVm.showPlaylistView.playlists.splice(indexSong, 1);
              }
            }
          }
        }

        return {
          decorate: decorate
        };
      }]);
})();
