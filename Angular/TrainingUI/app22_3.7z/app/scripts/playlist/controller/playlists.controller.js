(function () {
  'use strict';
  angular.module('songApp')
    .controller('PlaylistCtrl', ['$location', 'PlayListFactory', 'SongFactory', 'CommonService', 'commonConstant',
      function ($location, PlayListFactory, SongFactory, CommonService, commonConstant) {

        var vm = this;
        var selectedPlaylist = {};
        var copyOfSelectedPlaylist = {};

        init();
        function init() {
          //common mode
          vm.titleName = 'PlayLists';
          vm.templatePath = '';//path of template html
          vm.configBreadcrumb =
            {
              titles: ['Home', 'Playlist']
            };

          //show mode
          vm.searchText = {text: ''};// set the default search/filter
          vm.isDisabledBtn = {status: true};
          vm.listCheckedChkBox = [];
          vm.isCheckedHeaderChkbox = {status: false};
          vm.titleColumns = ['ID', 'Name', 'Description', 'Action'];

          //config paramater
          vm.configDataPlaylistTable = {
            items: [],
            titleColumns: ['ID', 'Name', 'Description', 'Action'],
            isCheckedHeaderChkbox: vm.isCheckedHeaderChkbox,
            disableCheckedAll: vm.isDisabledBtn,
            listCheckedChkBox: vm.listCheckedChkBox,
            searchText: vm.searchText
          };

          vm.configFuncPlaylistTable = {
            formatData: formatData,
            onDirectToEditPage: switchEditMode,
            onRemoveItemByIndex: removeByIndex
          };
          // end config

          vm.loadingState = true;
          vm.MODE_PLAYLIST = Object.freeze({
            SHOW: "SHOW",
            ADD: "ADD",
            EDIT: "EDIT"
          });
          vm.currentModeSong = '';

          // edit and create mode
          vm.isDisabledCreateOrApplyBtn = true;
          vm.playlistModel = {
            id: '',
            name: '',
            description: ''
          };//playlistModel is input to user or song selected.

          vm.SHOW_TAB = commonConstant.SHOW_TAB;
          vm.switchShowMode = switchShowMode;
          //default display showMode
          vm.switchShowMode();

          vm.isAddMode = isAddMode;
          vm.isShowMode = isShowMode;
          vm.isEditMode = isEditMode;
          vm.formatData = formatData;

          /*************** ADD PLAYLIST *****************/
          vm.isInputError = false;
          vm.addPlaylist = addPlaylist;
          vm.checkInput = checkInput;
          vm.switchAddMode = switchAddMode;

          /*************** EDIT PLAYLIST *****************/
          vm.isDisabledApplyRevertBtn = true;// disable revert and apply button
          vm.showInfoTab = true;
          vm.displayTab = displayTab;
          vm.songsOfPlaylist = [];
          vm.songsOfOriginalPlayList = [];
          vm.switchEditMode = switchEditMode;
          vm.updatePlaylist = updatePlaylist;

          /************** TAB SONG *********************/
          // checkbox in header table
          vm.isCheckedMasterChkBox = false;
          vm.stageChangeMasterChkBox = stageChangeMasterChkBox;
          //used for function edit playlist and checkbox of addSong Tab.

          /*
           * LOAD DATA FOR TABLE
           */
          vm.stageChangeChkBox = stageChangeChkBox; // event click for every table row
          //do change add song for playlist
          vm.addSongOfPlaylist = addSongOfPlaylist;
          vm.revertListSong = revertListSong;
          /******* delete ********/
          vm.removeByIndex = removeByIndex;
          vm.deletePlayLists = deletePlayLists;

        }

        function switchShowMode() {
          vm.templatePath = 'scripts/playlist/views/playlistTemplate.html';
          vm.titleName = 'PlayLists';
          vm.currentModePlayList = vm.MODE_PLAYLIST.SHOW;
          vm.showTab = vm.SHOW_TAB.INFORMATION;
          loadPlaylist();
        }

        function isAddMode() {
          return vm.currentModePlayList === vm.MODE_PLAYLIST.ADD;
        }

        function isShowMode() {
          return vm.currentModePlayList === vm.MODE_PLAYLIST.SHOW;
        }

        function isEditMode() {
          return vm.currentModePlayList === vm.MODE_PLAYLIST.EDIT;
        }

        function formatData(data) {
          return {
            col1: data.id,
            col2: data.name,
            col3: data.description
          }
        }

        function loadPlaylist() {
          vm.playlists = [];// get the list song
          var playlistPromise = CommonService.getData('api/playlist');
          playlistPromise.then(function (data) {
            vm.playlists = angular.copy(data);
            vm.configDataPlaylistTable.items = vm.playlists;
            // console.log('success ', data);
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /*************** ADD PLAYLIST *****************/

        function checkInput() {

          if (vm.playlistModel.name === "" || angular.isUndefined(vm.playlistModel.name)) {
            vm.isInputError = true;
            vm.isDisabledCreateOrApplyBtn = true;
          } else {
            vm.isInputError = false;
            vm.isDisabledCreateOrApplyBtn = false;
          }

          if (vm.currentModePlayList === vm.MODE_PLAYLIST.EDIT) {
            if (vm.playlistModel.name != selectedPlaylist.name || vm.playlistModel.description != selectedPlaylist.description) {
              vm.isDisabledCreateOrApplyBtn = false;
            } else {
              vm.isDisabledCreateOrApplyBtn = true;
            }
          }
        }

        function switchAddMode() {

          vm.titleName = 'Create Playlist';
          vm.templatePath = 'scripts/playlist/views/addPlaylist.html';
          vm.currentModePlayList = vm.MODE_PLAYLIST.ADD;
          resetValues();
        }

        function resetValues() {
          vm.playlistModel.id = '';
          vm.playlistModel.name = '';
          vm.playlistModel.description = '';
          vm.isDisabledCreateOrApplyBtn = true;
        }

        function addPlaylist() {
          vm.playlistModel.id = vm.playlists.length + 1;
          var addPlaylistPromise = CommonService.postData('api/playlist', angular.copy(vm.playlistModel));
          addPlaylistPromise.then(function (data) {
            resetValues();
            vm.switchShowMode();
            loadPlaylist();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /*************** EDIT PLAYLIST *****************/

        function displayTab(tagName) {
          if ('infor' === tagName && vm.showTab === 0) {
            vm.showTab++;
          }
          else if ('addsong' === tagName && vm.showTab === 1) {
            vm.showTab--;
            loadSongs();
          }
        }

        function switchEditMode(selectedplaylist) {

          selectedPlaylist = selectedplaylist;
          // used for check selectedPlaylist is change songs value(selectedPlaylist.songs != vm.copyOfSelectedPlaylist.songs)
          copyOfSelectedPlaylist = angular.copy(selectedPlaylist);

          vm.titleName = 'Edit Playlist';
          vm.templatePath = 'scripts/playlist/views/editPlaylist.html';
          vm.currentModePlayList = vm.MODE_PLAYLIST.EDIT;

          vm.playlistModel.id = selectedplaylist.id;
          vm.playlistModel.name = selectedplaylist.name;
          vm.playlistModel.description = selectedplaylist.description;
        }

        function updatePlaylist() {
          var playlist = vm.playlists[vm.playlists.indexOf(selectedPlaylist)];
          playlist.name = vm.playlistModel.name;
          playlist.description = vm.playlistModel.description;
          var updateSongPromise = CommonService.postData('api/playlist', playlist);
          updateSongPromise.then(function (data) {
            resetValues();
            vm.switchShowMode();
            loadPlaylist();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /************** TAB SONG *********************/

        // event change model for checkbox all
        function stageChangeMasterChkBox() {
          if (vm.songs.length > 0) {
            vm.isDisabledApplyRevertBtn = false;
            var listId = [];
            for (var i = 0; i < vm.songs.length; i++) {
              vm.songs[i].songChecked = vm.isCheckedMasterChkBox;
              listId.push(vm.songs[i].id);
            }
            selectedPlaylist.songs.length = 0;
            if (vm.isCheckedMasterChkBox) {
              selectedPlaylist.songs = angular.copy(listId);
            }
          }
          else {
            vm.isCheckedMasterChkBox = false;
          }
        }

        /*** Used for Tab Song ***/
        function loadSongs() {
          vm.songs = [];// get the list song
          var songPromise = CommonService.getData('api/song');
          songPromise.then(function (data) {
            vm.songs = angular.copy(data);
            //set data for ov-table-list-view
            vm.configDataPlaylistTable.items = vm.songs;
            for (var index = 0; index < vm.songs.length; index++) {
              var song = vm.songs[index];
              song.songChecked = selectedPlaylist.songs.indexOf(song.id) > -1;
            }
            if (vm.songs.length === selectedPlaylist.songs.length) {
              vm.isCheckedMasterChkBox = true;
            }
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /*
         * LOAD DATA FOR TABLE
         */

        function stageChangeChkBox(songId) {
          //1. add or remove song id of selectedPlaylist
          selectedPlaylist.songs.indexOf(songId) > -1 ? selectedPlaylist.songs.splice(selectedPlaylist.songs.indexOf(songId), 1) : selectedPlaylist.songs.push(songId);
          // listSongOfPlayList is change element
          copyOfSelectedPlaylist.songs.length === selectedPlaylist.songs.length ? vm.isDisabledApplyRevertBtn = true : vm.isDisabledApplyRevertBtn = false;
          //is select all checkbox
          vm.songs.length === selectedPlaylist.songs.length ? vm.isCheckedMasterChkBox = true : vm.isCheckedMasterChkBox = false;

        }

        /*
         *  event of Revert button
         */
        function revertListSong() {
          vm.isCheckedMasterChkBox = false;
          vm.isDisabledApplyRevertBtn = true;
          //reset value of selectedPlaylist because when clicked will change songs value
          selectedPlaylist.songs = angular.copy(copyOfSelectedPlaylist.songs);
          loadSongs();
        }

        function addSongOfPlaylist() {

          copyOfSelectedPlaylist = angular.copy(selectedPlaylist);
          var playlistPromise = CommonService.putData('api/playlist', angular.copy(selectedPlaylist));
          playlistPromise.then(function (data) {
            vm.songs = angular.copy(data);
            loadSongs();
            vm.isCheckedMasterChkBox = false;
            vm.isDisabledApplyRevertBtn = true;
            // vm.switchShowMode();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /******* delete ********/
        function removeByIndex(index) {
          var playlist = {id: [vm.playlists[index].id]};
          var deletePromise = CommonService.deleteData('api/playlist', playlist);
          deletePromise.then(function (response) {
            //reload songs
            loadPlaylist();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
            }
          );
        }

        function deletePlayLists() {
          if (vm.isCheckedHeaderChkbox.status) {
            vm.playlists.length = 0;
            vm.isCheckedHeaderChkbox.status = false;
            vm.isDisabledBtn.status = true;
          }
          else {
            if (vm.listCheckedChkBox.length === vm.playlists.length) {
              vm.isCheckedHeaderChkbox.status = false;
            }
            deletePlayListOf(vm.listCheckedChkBox);
            vm.listCheckedChkBox.length = 0;
            vm.isDisabledBtn.status = true;
          }
        }

        function deletePlayListOf(lstSongId) {

          for (var index = 0; index < lstSongId.length; index++) {
            for (var indexSong = 0; indexSong < vm.playlists.length; indexSong++) {
              if (lstSongId[index] === vm.playlists[indexSong].id) {
                vm.playlists.splice(indexSong, 1);
              }
            }
          }
        }
      }])
  ;
})();
