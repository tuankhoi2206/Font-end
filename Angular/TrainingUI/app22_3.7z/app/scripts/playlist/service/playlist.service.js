(function () {
  'use strict';
  angular.module('songApp')
    .factory('PlayListFactory', ['$http', function ($http) {
      /* set get */
      var playlistCache = [];

      function getData(url) {
        return $http({
          method: 'GET',
          url: url
        }).then(
          function successCallback(response) {
            return angular.copy(response.data);
          }, function errorCallback(response) {
            return [];
          });
      }

      // lstSongOfPlayList
      var songOfPlayListCache = [];

      $http({
        method: 'GET',
        url: 'scripts/playlist/data/songOfPlayListData.json'
      }).then(
        function successCallback(response) {
          songOfPlayListCache = angular.copy(response.data);
        }, function errorCallback(response) {
          songOfPlayListCache = angular.copy(response.data);
        });

      function getListSongOfPlayList() {
        return songOfPlayListCache;
      }

      return {
        getData: getData
      }
    }])
})();
