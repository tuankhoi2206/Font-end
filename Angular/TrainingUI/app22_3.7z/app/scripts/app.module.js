'use strict';

angular
  .module('songApp', [
    // 'ngAnimate',
    // 'ngCookies',
    // 'ngResource',
    'ngRoute'
    // 'ngSanitize',
    // 'ngTouch'
  ]);
