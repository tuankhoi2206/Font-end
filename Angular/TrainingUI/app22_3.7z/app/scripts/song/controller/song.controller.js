(function () {
  'use strict';
  angular.module('songApp')
  // .constant('songConstant', {song: {show: 'SHOW'}})
    .controller('SongCtrl', ['$location', 'SongFactory', '$timeout', 'CommonService', 'commonConstant',
      function ($location, SongFactory, $timeout, CommonService, commonConstant) {

        var vm = this;

        vm.cache = SongFactory.cache;
        var selectedSong = {};//save song selected when click delete button in table row
        init();
        function init() {

          vm.titles = ['Home', 'Song'];//set title for breadcrumbs nav

          vm.configBreadcrumb =
            {
              titles: ['Home', 'Song']
            };

          // show mode
          vm.searchText = {text: ''};// set the default search/filter
          vm.listCheckedChkBox = [];//list checkbox is check
          vm.isCheckedHeaderChkbox = {status: false};
          vm.isDisabledDeleteBtn = {status: true};

          //config paramater
          vm.configDataSongTable = {
            items: [],
            titleColumns: ['ID', 'Name', 'Artist', 'Action'],
            isCheckedHeaderChkbox: vm.isCheckedHeaderChkbox,
            disableCheckedAll: vm.isDisabledDeleteBtn,
            listCheckedChkBox: vm.listCheckedChkBox,
            searchText: vm.searchText
          };

          vm.configFuncSongTable = {
            formatData: formatData,
            onDirectToEditPage: switchEditMode,
            onRemoveItemByIndex: removeSongById
          };
          // end config

          vm.loadingState = true;
          loadSongs();

          vm.MODE_SONG = Object.freeze({
            SHOW: 'SHOW',
            ADD: 'ADD',
            EDIT: 'EDIT'
          });
          vm.currentModeSong = '';

          vm.switchShowMode = switchShowMode;
          // vm.switchShowMode();

          vm.isAddMode = isAddMode;
          vm.isShowMode = isShowMode;
          vm.isEditMode = isEditMode;

          /*************** ADD SONG *****************/
          vm.isInputError = false;
          vm.addSong = addSong;
          vm.checkInput = checkInput;
          vm.switchAddMode = switchAddMode;
          vm.doCancel = doCancel;

          /*************** EDIT SONG *****************/
          vm.switchEditMode = switchEditMode;
          vm.updateSong = updateSong;

          /*************** REMOVE SONG ***************/
          vm.removeSongs = removeSongs;

        }

        function switchShowMode() {
          vm.cache.currentView = SongFactory.views.table;
          //reset checkbox
          for (var i = 0; i < vm.songs.length; i++) {
            vm.songs[i].isChecked = false;
          }
        }

        function isAddMode() {
          return vm.cache.currentView.name === vm.MODE_SONG.ADD;
        }

        function isShowMode() {
          return vm.cache.currentView.name === vm.MODE_SONG.SHOW;
        }

        function isEditMode() {
          return vm.cache.currentView.name === vm.MODE_SONG.EDIT;
        }

        function loadSongs() {
          vm.songs = [];// get the list song
          var songPromise = CommonService.getData('api/song');
          songPromise.then(function (response) {
            vm.songs = response.data;
            vm.configDataSongTable.items = vm.songs;
            console.log('success ', response.data);
          }, function (error) {
            console.log('error ', error)
          }).finally(function () {
            vm.loadingState = false;
          });
        }

        /*************** ADD SONG *****************/
        function addSong() {
          vm.cache.songModel.id = vm.songs.length + 1;
          CommonService.postData('api/song', angular.copy(vm.cache.songModel))
            .then(function (data) {
              console.log('success addSong ', data);
              clearSongModel();
              vm.switchShowMode();
              loadSongs();
            }, function (error) {
              console.log('error ', error)
            }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        function checkInput() {

          if (vm.cache.songModel.title === '' || angular.isUndefined(vm.cache.songModel.title)) {
            vm.isInputError = true;
            vm.cache.isDisabledCreateOrApplyBtn.status = true;
          } else {
            vm.isInputError = false;
            vm.cache.isDisabledCreateOrApplyBtn.status = false;
          }

          if (vm.cache.currentView.name === vm.MODE_SONG.EDIT) {
            if (vm.cache.songModel.title !== selectedSong.title || vm.cache.songModel.artists !== selectedSong.artists) {
              vm.cache.isDisabledCreateOrApplyBtn.status = false;
            } else {
              vm.cache.isDisabledCreateOrApplyBtn.status = true;
            }
          }
        }

        function switchAddMode() {
          vm.cache.currentView = SongFactory.views.add;
          vm.currentModeSong = vm.MODE_SONG.ADD;
        }

        function doCancel() {
          clearSongModel();
          switchShowMode();
        }

        function clearSongModel() {
          vm.cache.songModel.id = '';
          vm.cache.songModel.title = '';
          vm.cache.songModel.artists = '';
          vm.cache.isDisabledCreateOrApplyBtn.status = true;
        }

        /*************** EDIT SONG *****************/
        function switchEditMode(_selectedSong) {

          selectedSong = _selectedSong;
          vm.cache.songModel = angular.copy(_selectedSong);
          vm.cache.currentView = SongFactory.views.edit;
          vm.currentModeSong = vm.MODE_SONG.EDIT;

        }

        function updateSong() {

          var song = vm.songs[vm.songs.indexOf(selectedSong)];
          song.title = vm.cache.songModel.title;
          song.artists = vm.cache.songModel.artists;

          var updateSongPromise = CommonService.putData('api/song', song);
          updateSongPromise.then(function (data) {
            console.log('success updateSong ', data);
            clearSongModel();
            vm.switchShowMode();
            loadSongs();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
              vm.loadingState = false;
            }
          );
        }

        /*************** REMOVE SONG *****************/
        function removeSongByListID(listCheckedChkBox) {
          var songs = {id: listCheckedChkBox};
          console.log('removeSongByListID ' + songs.id);
          var deletePromise = CommonService.deleteData('api/song', angular.copy(songs));
          deletePromise.then(function (response) {
            console.log('success removeSongByListID ', response);
            //reload songs
            loadSongs();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
            }
          );
        }

        /*** checkbox in header table ***/
        function removeSongs() {
          if (vm.isCheckedHeaderChkbox.status) {
            vm.songs.length = 0;
            vm.isCheckedHeaderChkbox.status = false;
            vm.isDisabledDeleteBtn.status = true;
          }
          else {
            if (angular.equals(vm.listCheckedChkBox.length, vm.songs.length)) {
              vm.isCheckedHeaderChkbox.status = false;
            }
            removeSongByListID(vm.listCheckedChkBox);
            vm.listCheckedChkBox.length = 0;
            vm.isDisabledDeleteBtn.status = true;
          }
        }

        function removeSongById(index) {
          var songs = {id: [vm.songs[index].id]};
          var deletePromise = CommonService.deleteData('api/song', songs);
          deletePromise.then(function (response) {
            console.log('success ', response);
            //reload songs
            loadSongs();
          }, function (error) {
            console.log('error ', error)
          }).finally(
            function () {
            }
          );
        }

        /*format data used for List-view*/
        function formatData(data) {
          return {
            col1: data.id,
            col2: data.title,
            col3: data.artists
          }
        }
      }
    ])
})();
