/**
 * Created by vtkhoi on 2/21/2017.
 */
(function () {
  'use strict';
  angular.module('songApp')
    .factory('SongFactory', ['$http', function ($http) {

      var songType = {
        title: '',
        artists: ''
      };

      var MODE_SONG = Object.freeze({
        SHOW: 'SHOW',
        ADD: 'ADD',
        EDIT: 'EDIT'
      });

      var views = {
        table: {
          title: 'Songs',
          name: MODE_SONG.SHOW,
          templateUrl: 'scripts/song/views/songTemplate.html'
        },
        add: {
          title: 'Create Songs',
          name: MODE_SONG.ADD,
          templateUrl: 'scripts/song/views/addOrEditSongTemplate.html'
        },
        edit: {
          title: 'Edit Songs',
          name: MODE_SONG.EDIT,
          templateUrl: 'scripts/song/views/addOrEditSongTemplate.html'
        }
      };

      var cache = {
        songModel: {
          id: '',
          title: '',
          artists: ''
        },
        isDisabledCreateOrApplyBtn: {status: true},
        currentView: views.table
      };

      function getSongType() {
        return songType;
      }

      function getData(url) {
        return $http({
          method: 'GET',
          url: url
        }).then(
          function successCallback(response) {
            return angular.copy(response.data);
          }, function errorCallback(response) {
            return [];
          });
      }

      return {
        getSongType: getSongType,
        getData: getData,
        views: views,
        cache: cache
      }
    }])
})();
