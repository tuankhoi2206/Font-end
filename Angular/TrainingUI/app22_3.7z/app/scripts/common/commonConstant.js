/**
 * Created by vtkhoi on 3/16/2017.
 */
angular.module('songApp')
  .constant('songConstant', {song: {show: 'SHOW'}})
