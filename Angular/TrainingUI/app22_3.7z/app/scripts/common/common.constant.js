angular.module('songApp')
  .constant('commonConstant', {
    /*** Mode display of page ***/
    MODE: {
      SHOW: 'SHOW',
      ADD: 'ADD',
      EDIT: 'EDIT'
    },
    /*** Mode display of tab ***/
    SHOW_TAB: {
      INFORMATION: 1,
      ADDSONG: 2
    },
    /*** HTTP method ***/
    HTTP_METHOD: {
      GET: 'GET',
      POST: 'POST',
      PUT: 'PUT',
      DELETE: 'DELETE'
    }
  })
