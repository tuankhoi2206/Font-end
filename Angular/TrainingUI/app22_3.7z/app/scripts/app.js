(function () {
  'use strict';
  angular.module('songApp')
    .controller('AppCtrl', ['$location', '$scope', 'SongFactory',
      function ($location, $scope, SongFactory) {
        var vm = this;
        //set css
        vm.btnSongCss = 'active-btn';
        vm.btnPlaylistCss = '';

        vm.changeRoute = function (path) {

          $location.path('/'.concat(path));

          if ('songs' === path || '/' === path) {
            $scope.titleName = 'Songs';
            vm.btnSongCss = 'active-btn';
            vm.btnPlaylistCss = '';
          }
          else {
            $scope.titleName = 'Playlists';
            vm.btnSongCss = '';
            vm.btnPlaylistCss = 'active-btn';

          }
        };

        vm.updateSong = function (songTitle, songArtist) {
          SongFactory.editSong(songTitle, songArtist);
          vm.changeRoute('songs');
        }

      }])
  ;
})();
