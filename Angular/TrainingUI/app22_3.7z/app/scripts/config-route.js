'use strict';

angular
  .module('songApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'scripts/song/views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'vm'
      })//song
      .when('/songs', {
        templateUrl: 'scripts/song/views/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'vm'
      })
      .when('/playlist', {
        templateUrl: 'scripts/playlist/views/playlists.html',
        controller: 'PlaylistCtrl',
        controllerAs: 'vm'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
