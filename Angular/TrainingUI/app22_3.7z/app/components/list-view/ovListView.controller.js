(function () {
  'use strict';
  angular.module('songApp')
    .controller('ListViewCtrl', ['$scope',
      function ($scope) {
        var vm = this;
        vm.elementFormat = {};
        vm.configData.disableCheckedAll.status = true; //set is enable allDelete Button
        vm.configData.isCheckedHeaderChkbox.status = false;

        vm.setElementFormat = function (data) {
          vm.elementFormat.col1 = data.col1;
          vm.elementFormat.col2 = data.col2;
          vm.elementFormat.col3 = data.col3;
        }

        vm.configData.listCheckedChkBox.length = 0;// save list item checked.
        vm.stageChangeHeaderCheckbox = function () {
          vm.configData.listCheckedChkBox.length = 0;
          for (var i = 0; i < vm.items.length; i++) {
            vm.items[i].isChecked = vm.configData.isCheckedHeaderChkbox.status;
            vm.configData.listCheckedChkBox.push(vm.items[i].id);
          }
          // enable AllDeleteBtn
          vm.configData.disableCheckedAll.status = !vm.configData.isCheckedHeaderChkbox.status;
        };

        vm.stageChangeChkBox = function stageChangeChkBox(songId) {

          /* exist songId*/
          if (vm.configData.listCheckedChkBox.indexOf(songId) < 0) {
            vm.configData.listCheckedChkBox.push(songId);
          }
          else {
            vm.configData.listCheckedChkBox.splice(vm.configData.listCheckedChkBox.indexOf(songId), 1);
          }

          /* display checkbox and AllDelete Button */
          if (vm.configData.listCheckedChkBox.length == 0) {
            vm.configData.disableCheckedAll.status = true;
          }
          else {
            vm.configData.disableCheckedAll.status = false;
          }

          if (vm.configData.listCheckedChkBox.length === vm.items.length) {
            vm.configData.isCheckedHeaderChkbox.status = true;
          } else {
            vm.configData.isCheckedHeaderChkbox.status = false;
          }
        };

        //used for Remove Button
        vm.indexSelectedItem = 0;
        vm.saveIndex = function (index) {
          vm.indexSelectedItem = index;
        };
      }])
  ;
})();
