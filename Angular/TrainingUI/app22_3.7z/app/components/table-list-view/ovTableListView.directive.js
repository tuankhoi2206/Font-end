/**
 * Created by vtkhoi on 3/9/2017.
 */
angular.module('songApp').directive('ovTableListView', function () {
  return {
    restrict: 'E',
    templateUrl: 'components/table-list-view/ovTableListViewDirective.html',
    scope: {
      configData: '=',
      configFunction: '='
    },
    controller: 'TableListViewCtrl',
    controllerAs: 'vm',
    bindToController: true
  };
});
//generate option of directive
// idTv: '@?',
//   items: '=', // list item
//   titleColumns: '=',
//   formatData: '=',
//   disableCheckedAll: '=?',
//   searchText: '=?',
//   isCheckedHeaderChkbox: '=?',
//   listCheckedChkBox: '=?',
//   onDirectToEditPage: '=?',// used for edit button direct to edit page
//   onRemoveItemByIndex: '=?',// used for message dialog
//   // attribute of ListView
//   isCheckedItem: '@?',
//   onRemove: '&'// used for message dialog
