/**
 * Created by vtkhoi on 3/10/2017.
 */
(function () {
  'use strict';
  angular.module('songApp')
    .controller('TableListViewCtrl', ['$scope',
      function ($scope) {
        var vm = this;
      }])
  ;
})();
