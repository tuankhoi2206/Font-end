(function () {
  'use strict';
  angular.module('songApp')
    .controller('PlaylistCtrl', ['$location', 'PlayListFactory', 'SongFactory', 'CommonService', 'commonConstant',
      'PlaylistViewService', 'PlaylistCreateService',
      function ($location, PlayListFactory, SongFactory, CommonService, commonConstant, PlaylistViewService, PlaylistCreateService) {

        var vm = this;
        vm.cache = PlayListFactory.cache;

        function init() {
          //common mode
          vm.common = {
            configBreadcrumb: {titles: ['app.common.home', 'app.common.playlists']},
            loadingState: true,
            function: {
              // checkValueInput: checkValueInput
            }
          };

          //decorate necessary functions from PlaylistViewService
          PlaylistViewService.decorate(vm);
          PlaylistCreateService.decorate(vm);


        }
        init();


        /*
         * cancel button of Create Playlist, Information Tab, AddSong Tab
         * Reset Page
         */
        // function doCancel() {
        //   //cache tab
        //   if (vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG) {
        //     vm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
        //     resetCheckBoxSongs();
        //   } else if (vm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADD) {
        //     resetIsDisabledCreateOrApplyBtn();
        //   }
        //   vm.common.isInputError = false;
        //   clearCacheCurrentPlaylist();
        //   clearCachePlaylistModel();
        //   switchShowMode();
        // }

      }])
  ;
})();
