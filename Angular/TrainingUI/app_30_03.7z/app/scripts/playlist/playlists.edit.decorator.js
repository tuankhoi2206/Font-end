/**
 * Created by vtkhoi on 3/29/2017.
 */
(function () {
  'use strict';
  angular
    .module('songApp')
    .factory('PlaylistViewService', ['$location', 'PlayListFactory', 'SongFactory', 'CommonService', 'commonConstant',
      function ($location, PlayListFactory, SongFactory, commonService, commonConstant) {

        var injectedVm;

        function decorate(vm) {
          injectedVm = vm;
          injectedVm.cache = PlayListFactory.cache;
          initService();
          loadSongs();
        }

        function initService() {

          injectedVm.editPlaylistView = {
            showInfoTab: true,
            inforTab: {
              playlistModel: {id: '', name: '', description: ''}
            },
            addSongTab: {
              songs: [],
              // checkbox in header table
              isCheckedHeaderChkbox: false,
              songsOfPlaylist: [],
              listCheckedChkBoxSong: []//song table used for addSong Tab},
            },
            function: {
              isInforTab: isInforTab,
              isSongTab: isSongTab,
              isEditMode: isEditMode,
              displayTab: displayTab,
              updatePlaylist: updatePlaylist,
              switchShowMode: PlayListFactory.function.switchShowMode,
              revertListSong: revertListSong,
              stageChangeSongHeaderCheckBox: stageChangeSongHeaderCheckBox,
              stageChangeSongCheckBox: stageChangeSongCheckBox,
              addSongOfPlaylist: addSongOfPlaylist,
              doSongUpdateCancel: doSongUpdateCancel,
              doEditPlaylistCancel: doEditPlaylistCancel
            }
          };
        }


        function isEditMode() {
          return injectedVm.cache.currentView.name === commonConstant.VIEW_MODE.EDIT;
        }

        function isInforTab() {
          return injectedVm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.INFORMATION;
        }

        function isSongTab() {
          return injectedVm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG;
        }

        function doSongUpdateCancel() {
          resetCheckBoxSongs();
          resetIsDisabledCreateOrApplyBtn();
          clearCacheCurrentPlaylist();
          PlayListFactory.function.clearCachePlaylistModel();
          PlayListFactory.function.switchShowMode();
        }

        function doEditPlaylistCancel() {
          //cache tab
          if (injectedVm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADDSONG) {
            injectedVm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
            resetCheckBoxSongs();
          } else if (injectedVm.cache.editPlaylistView.currentTab === commonConstant.SHOW_TAB.ADD) {
            resetIsDisabledCreateOrApplyBtn();
          }
          injectedVm.common.isInputError = false;
          clearCacheCurrentPlaylist();
          commonService.function.clearCachePlaylistModel();
          commonService.function.switchShowMode();
        }

        function clearCacheCurrentPlaylist() {
          injectedVm.cache.editPlaylistView.currentPlaylist = {id: '', name: '', description: '', songs: []};
        }

        function resetIsDisabledCreateOrApplyBtn() {
          injectedVm.cache.common.isDisabledCreateOrApplyBtn.status = true;
        }

        function displayTab(tagName) {
          if ('infor' === tagName) {
            injectedVm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.INFORMATION;
          }
          else if ('addsong' === tagName) {
            injectedVm.cache.editPlaylistView.currentTab = commonConstant.SHOW_TAB.ADDSONG;
            loadSongs();
          }
        }

        // function isShowMode() {
        //   return injectedVm.cache.currentView.name === commonConstant.VIEW_MODE.SHOW;
        // }

        /*** Used for Tab Song ***/
        function loadSongs() {
          commonService.getData(commonConstant.API.SONG).then(function (response) {

            injectedVm.editPlaylistView.addSongTab.songs = response.data;
            // injectedVm.configDataPlaylistTable.items = response.data;
            setCheckBoxsModel();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              injectedVm.common.loadingState = false;
            }
          );
        }

        function resetCheckBoxSongs() {
          var songs = injectedVm.editPlaylistView.addSongTab.songs;
          for (var i = songs.length; i--;) {
            songs[i].songChecked = false;
          }
        }

        function updatePlaylist() {
          commonService.putData('api/playlist', injectedVm.cache.common.playlistModel).then(function () {
            resetValues();
            PlayListFactory.function.switchShowMode();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              injectedVm.common.loadingState = false;
            }
          );
        }

        function resetValues() {
          injectedVm.cache.common.isInputError.status = false;
          PlayListFactory.function.clearCachePlaylistModel();
          PlayListFactory.function.resetIsDisabledCreateOrApplyBtn();
          PlayListFactory.function.clearCacheCurrentPlaylist();
        }

        // event change model for checkbox all
        function stageChangeSongHeaderCheckBox() {
          var songs = injectedVm.editPlaylistView.addSongTab.songs;
          if (songs.length > 0) {
            injectedVm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = false;
            var listId = [];
            for (var i = songs.length; i--;) {
              songs[i].songChecked = injectedVm.editPlaylistView.addSongTab.isCheckedHeaderChkbox;
              listId.push(songs[i].id);
            }
            injectedVm.cache.currentPlaylist.songs.length = 0;//injectedVm.isCheckedHeaderChkbox is false
            if (injectedVm.editPlaylistView.addSongTab.isCheckedHeaderChkbox) {
              injectedVm.cache.currentPlaylist.songs = listId;
            }
            setCheckBoxsModel();
          }
          else {
            injectedVm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = false;
          }
        }

        function stageChangeSongCheckBox(songId) {
          //1. add or remove song id of selectedPlaylist
          var currentPlaylist = injectedVm.cache.currentPlaylist;
          if (currentPlaylist.songs.indexOf(songId) > -1) {
            currentPlaylist.songs.splice(currentPlaylist.songs.indexOf(songId), 1);
          }
          else {
            currentPlaylist.songs.push(songId);
          }

          //2. case songs changed song equals currentPlaylist.songs
          //playlistModel.songs []
          //currentPlaylist.songs []
          if (angular.equals(injectedVm.cache.common.playlistModel.songs, currentPlaylist.songs)) {
            injectedVm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = true;
          }
          else {
            injectedVm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = false;
          }

          //3. is select all checkbox
          if (injectedVm.editPlaylistView.addSongTab.songs.length === injectedVm.cache.currentPlaylist.songs.length) {
            injectedVm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = true;
          } else {
            injectedVm.editPlaylistView.addSongTab.isCheckedHeaderChkbox = false;
          }
        }

        /*
         *  event of Revert button
         *  Reset currentPlaylist.songs
         */
        function revertListSong() {
          injectedVm.isCheckedHeaderChkbox = false;
          resetIsDisabledCreateOrApplyBtn();
          resetCacheIsDisabledApplyRevertBtn();
          //reset value vm.cache.common.playlistModel.songs because when clicked will change songs value
          injectedVm.cache.currentPlaylist.songs = angular.copy(injectedVm.cache.common.playlistModel.songs);
          loadSongs();
        }

        function addSongOfPlaylist() {

          commonService.putData('api/playlist', angular.copy(injectedVm.cache.currentPlaylist)).then(function () {
            loadSongs();

            //aysn playlistModel and currentPlaylist after save
            injectedVm.cache.common.playlistModel = angular.copy(injectedVm.cache.currentPlaylist);
            if (injectedVm.editPlaylistView.addSongTab.songs.length !== injectedVm.cache.currentPlaylist.length) {
              injectedVm.isCheckedHeaderChkbox = false;
            }
            resetCacheIsDisabledApplyRevertBtn();
            resetIsDisabledCreateOrApplyBtn();
            // vm.switchShowMode();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              injectedVm.common.loadingState = false;
            }
          );
        }

        function resetCacheIsDisabledApplyRevertBtn() {
          injectedVm.cache.editPlaylistView.addSongTab.isDisabledApplyRevertBtn.status = true;
        }

        function setCheckBoxsModel() {
          var editPlayListView = injectedVm.editPlaylistView.addSongTab;
          var cacheSongs = injectedVm.cache.currentPlaylist.songs;

          if (cacheSongs.length > 0) {
            for (var index = editPlayListView.songs.length; index--;) {
              var song = editPlayListView.songs[index];
              song.isChecked = cacheSongs.indexOf(song.id) > -1;
            }

            if (editPlayListView.songs.length === cacheSongs.length) {
              editPlayListView.isCheckedHeaderChkbox = true;
            }
            else {
              editPlayListView.isCheckedHeaderChkbox = false;
            }
          } else {
            for (var i = editPlayListView.songs.length; i--;) {
              var ssong = editPlayListView.songs[i];
              ssong.isChecked = false;
            }
          }
        }

        return {
          decorate: decorate
        };

      }]);
})();
