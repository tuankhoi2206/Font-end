/**
 * Created by vtkhoi on 3/29/2017.
 */
(function () {
  'use strict';
  angular
    .module('songApp')
    .factory('PlaylistCreateService', ['$location', 'PlayListFactory', 'SongFactory', 'CommonService', 'commonConstant',
      function ($location, PlayListFactory, SongFactory, commonService, commonConstant) {

        var injectedVm;

        function decorate(vm) {
          injectedVm = vm;
          injectedVm.cache = PlayListFactory.cache;
          initService();
        }

        function initService() {

          injectedVm.addPlaylistView = {
            playlistModel: {id: '', name: '', description: ''},
            isDisabledCreateOrApplyBtn: injectedVm.cache.common.isDisabledCreateOrApplyBtn,
            function: {
              isAddMode: isAddMode,
              addPlaylist: addPlaylist,
              switchAddMode: PlayListFactory.function.switchAddMode,
              checkInputValue: PlayListFactory.function.checkInputValue,
              doCreateCancel: doCreateCancel
            }
          }
          ;
        }

        function isAddMode() {
          return injectedVm.cache.currentView.name === commonConstant.VIEW_MODE.ADD;
        }

        function addPlaylist() {
          commonService.postData(commonConstant.API.PLAYLIST, angular.copy(injectedVm.cache.common.playlistModel)).then(function () {
            resetValues();
            PlayListFactory.function.switchShowMode();
          }, function (error) {
            console.log('error ', error);
          }).finally(
            function () {
              injectedVm.common.loadingState = false;
            }
          );
        }

        function resetValues() {
          injectedVm.cache.common.isInputError.status = false;
          PlayListFactory.function.clearCachePlaylistModel();
          PlayListFactory.function.resetIsDisabledCreateOrApplyBtn();
        }

        function doCreateCancel() {
          resetValues();
          PlayListFactory.function.switchShowMode();
        }

        return {
          decorate: decorate
        };
      }]);
})();
