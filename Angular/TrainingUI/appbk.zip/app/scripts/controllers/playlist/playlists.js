/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('PlaylistCtrl', function ($location, PlayListFactory, $scope) {

    var vm = this;
    vm.titleName = "PlayLists";
    vm.searchFish = '';// set the default search/filter
    vm.lstPlayList = PlayListFactory.getListPlayList();// get the list song
    vm.sortType = 'name'; // set the default sort type
    vm.sortReverse = false;  // set the default sort order
    vm.isDisabledBtn = true;
    vm.isCheckedMasterChkBox = false;

    vm.titles = ["Home", "Playlists"];

    vm.changeRoute = function (path) {
      $location.path("/".concat(path));
    }

    vm.changeRouteToEdit = function (playlist) {
      $location.path('editeplaylist');
      /** put selected song to service */
      PlayListFactory.setSelectedPlayList(playlist);
    }

    /******* delete ********/
    var indexOfSelectedPlaylist = '';
    vm.deletePlayList = function () {
      console.log("deletePlayList " + indexOfSelectedPlaylist);
      PlayListFactory.deletePlayListByIndex(indexOfSelectedPlaylist);
    };

    vm.getIndex = function (index) {
      console.log("getIndex " + index);
      indexOfSelectedPlaylist = index;
    }

    /*** checkbox in table ***/

    vm.stageChangeMasterChkBox = function () {
      for (var i = 0; i < vm.lstPlayList.length; i++) {
        vm.lstPlayList[i].playlistChecked = vm.isCheckedMasterChkBox;
        vm.lstCheckBox.push(vm.lstPlayList[i].id);
      }
      // enable AllDeleteBtn
      vm.isDisabledBtn = !vm.isCheckedMasterChkBox;
    }

    vm.lstCheckBox = [];

    vm.addOrRemoveListChecked = function (songId) {
      console.log("songId" + songId);
      /* exist songId*/
      for (var index = 0; index < vm.lstCheckBox.length; index++) {
        if (vm.lstCheckBox[index] === songId) {
          vm.lstCheckBox.splice(vm.lstCheckBox.indexOf(songId), 1);
          return;
        }
      }
      vm.lstCheckBox.push(songId);
      console.log("lstCheckBox.length " + vm.lstCheckBox.length);
    }

    vm.stageChangeChkBox = function stageChangeChkBox(songId) {
      vm.addOrRemoveListChecked(songId);

      /* display checkbox and AllDelete Button */
      if (vm.lstCheckBox.length == 0) {
        vm.isDisabledBtn = true;
      }
      else {
        vm.isDisabledBtn = false;
      }

      if (vm.lstCheckBox.length === vm.lstPlayList.length) {
        vm.isCheckedMasterChkBox = true;
      } else {
        vm.isCheckedMasterChkBox = false;
      }
    }

    /*** checkbox in header table ***/

    vm.deletePlayLists = function deletePlayLists() {

      if (vm.isCheckedMasterChkBox) {
        PlayListFactory.deletePlayLists();
      }
      else
        PlayListFactory.deletePlayListOf(vm.lstCheckBox);
    }
  })
;

