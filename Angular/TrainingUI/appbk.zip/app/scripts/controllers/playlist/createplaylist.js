/**
 * Created by vtkhoi on 2/24/2017.
 */
angular.module('fountainInjectApp')
  .controller('CreatePlaylistCtrl', function ($location,PlayListFactory, $scope) {

    var vm          = this;
    vm.titleName    = 'Create Playlist';
    vm.lstPlayList  = PlayListFactory.getListPlayList();// get the list song
    vm.hasError = false;
    vm.isDisabledCreate = true;

    vm.titles=["Home","Playlists"];

    /*** changeRoute ***/
    vm.changeRoute = function(path){
      $location.path("/".concat(path));
    };
    //model initial
    vm.newName = '';
    vm.newDescription = '';
    /******* add ********/
    vm.createPlayList= function () {
      PlayListFactory.addPlayList(vm.newName,vm.newDescription);
      vm.changeRoute('playlist');
    }

    vm.checkInput = function checkInput(songTitle) {
      // return (songTitle === "" || angular.isUndefined(songTitle)) ? vm.hasError=true :vm.hasError=false;
      if (songTitle === "" || angular.isUndefined(songTitle)) {
        vm.hasError = true;
        vm.isDisabledCreate = true;
      } else {
        vm.hasError = false;
        vm.isDisabledCreate = false;
      }
    }
  })
;
