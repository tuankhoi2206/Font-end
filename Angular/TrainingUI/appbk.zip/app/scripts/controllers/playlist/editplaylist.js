/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('EditPlaylistCtrl', function ($location, $scope, PlayListFactory, SongFactory) {

    var vm = this;
    // vm.titleName = 'Edit Playlist';
    vm.searchFish = '';// set the default search/filter
    vm.lstSong = angular.copy(SongFactory.getSongs());// get the list song
    vm.sortType = 'name'; // set the default sort type
    vm.sortReverse = false;  // set the default sort order

    vm.titles = ["Home", "Playlists"];

    vm.changeRoute = function (path) {
      $location.path("/".concat(path));
    }

    vm.showInfoTab = true;
    vm.showTab=1;
    vm.displayTab = function (tagName) {
      if('infor'===tagName && vm.showTab ===0 )
      {
        vm.showTab++;
      }
      else if('addsong'=== tagName && vm.showTab ===1)
      {
        vm.showTab--;
      }
    }



    // get playList clicked playlist view.
    var playlist = PlayListFactory.getSelectedPlayList();

    vm.playlistName = playlist.name;
    vm.playlistDescription = playlist.description;

    vm.updatePlaylist = function () {
      PlayListFactory.editPlayList(vm.playlistName, vm.playlistDescription);
      vm.changeRoute('playlist');
    }

    //load listsong of playlist used for addSong tab.
    /*** checkbox in header table ***/
    vm.isCheckedMasterChkBox = false;
    vm.stageChangeMasterChkBox = function () {
      for (var i = 0; i < vm.lstSong.length; i++) {
        vm.lstSong[i].songChecked = vm.isCheckedMasterChkBox;
        console.log(vm.lstSong[i].songChecked);
      }
    }

    vm.lstSongOfPlaylist = PlayListFactory.getListSongOfPlaylistByID(playlist.id);

    vm.isExistInListSongOfPlaylist = function () {

      for (var index = 0; index < vm.lstSongOfPlaylist.length; index++) {

        var songOfPlaylist = vm.lstSongOfPlaylist[index];
        for (var j=0; j < vm.lstSong.length; j++ )
        {
          var song= vm.lstSong[j];
          console.log("song.songChecked "+ song.songChecked);
          if(song.id === songOfPlaylist)
          {
            song.songChecked=true;
          }
        }
      }
    }

    vm.isExistInListSongOfPlaylist();

    vm.stageChangeChkBox = function stageChangeChkBox(songId) {

      if (vm.lstSongOfPlaylist.indexOf(songId) > -1) {
        vm.lstSongOfPlaylist.splice(vm.lstSongOfPlaylist.indexOf(songId), 1);
        console.log("lstSongOfPlaylist remove id " + songId);
      }
      else {
        vm.lstSongOfPlaylist.push(songId);
        console.log("lstSongOfPlaylist add id " + songId);
      }

      if (vm.lstSong.length === vm.lstSongOfPlaylist.length) {
        vm.isCheckedMasterChkBox = true;
      } else {
        vm.isCheckedMasterChkBox = false;
      }

      console.log("lstSongOfPlaylist.length  " + vm.lstSongOfPlaylist.length);

    }
    vm.revertListSong = function revertListSong() {
      console.log("revertListSong");
      vm.lstSongOfPlaylist = PlayListFactory.getListSongOfPlaylistByID(playlist.id);
      vm.lstSong = angular.copy(SongFactory.getSongs());
      vm.isExistInListSongOfPlaylist();
      vm.isCheckedMasterChkBox = false;
    }

    //do change add song for playlist

    vm.doApplyAddSong = function doApplyAddSong() {
      console.log("doApplyAddSong");
      PlayListFactory.updateSongForPlaylist(vm.lstSongOfPlaylist);
    }
  })
;


