/**
 * Created by vtkhoi on 2/16/2017.
 */
'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('EditSongCtrl', function ($location, SongFactory, $scope) {
    var vm = this;
    vm.titleName = 'EditSong';
    vm.titles   =["Home","Song"];

    var song = SongFactory.getSelectedSong();

    vm.songTitle=song.title;
    vm.songArtist=song.artists;

  })
;


