'use strict';
/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */

angular.module('fountainInjectApp')
  .controller('SongCtrl', function ($location, SongFactory, $scope) {
    var vm = this;

    vm.searchFish = '';// set the default search/filter
    vm.lstSong = SongFactory.getSongs();// get the list song
    vm.sortType = 'name'; // set the default sort type
    vm.sortReverse = false;  // set the default sort order
    vm.isDisabledBtn = true;
    vm.isCheckedMasterChkBox = false;

    vm.titleName = "Songs";
    vm.titles = ["Home", "Song"];

    /*** changeRoute ***/
    vm.changeRoute = function (path) {
      $location.path("/".concat(path));
    };

    vm.changeRouteToEdit = function (song) {
      $location.path('editsong');
      /** put selected song to service */
      SongFactory.setSelectedSong(song);
    };

    var indexOfSelectedSong = '';

    /*** remove ***/
    vm.remove = function () {
      SongFactory.removeSong(indexOfSelectedSong);
    };

    vm.getIndex = function (index) {

      indexOfSelectedSong = index;
    };

    /*** checkbox in table ***/
    vm.lstCheckBox = [];

    vm.addOrRemoveListChecked = function (songId) {
      console.log("songId" + songId);
      /* exist songId*/
      for (var index = 0; index < vm.lstCheckBox.length; index++) {
        if (vm.lstCheckBox[index] === songId) {
          vm.lstCheckBox.splice(vm.lstCheckBox.indexOf(songId), 1);
          return;
        }
      }
      vm.lstCheckBox.push(songId);
      // console.log("lstCheckBox.length " + vm.lstCheckBox.length);
    };

    vm.stageChangeChkBox = function stageChangeChkBox(songId) {

      vm.addOrRemoveListChecked(songId);

      /* display checkbox and AllDelete Button */
      if (vm.lstCheckBox.length == 0) {
        vm.isDisabledBtn = true;
      }
      else {
        vm.isDisabledBtn = false;
      }

      if (vm.lstCheckBox.length === vm.lstSong.length) {
        vm.isCheckedMasterChkBox = true;
      } else {
        vm.isCheckedMasterChkBox = false;
      }

    };

    vm.stageChangeMasterChkBox = function () {
      for (var i = 0; i < vm.lstSong.length; i++) {
        vm.lstSong[i].songChecked = vm.isCheckedMasterChkBox;
        vm.lstCheckBox.push(vm.lstSong[i].id);
      }
      // enable AllDeleteBtn
      vm.isDisabledBtn = !vm.isCheckedMasterChkBox;
    };

    /*** checkbox in header table ***/


    vm.removeSongs = function removeSongs() {
      if (vm.isCheckedMasterChkBox) {
        SongFactory.removeSongs();
      }
      else {
        SongFactory.removeSongById(vm.lstCheckBox);
      }

    }
  })
;

var data = [
  {title: 'abc', desc: 'def'}
];

function format(data) {
   return {
     name: data.title,
     description: data.desc
   }
}
