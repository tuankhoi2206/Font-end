/**
 * Created by vtkhoi on 2/17/2017.
 */'use strict';

/**
 * @ngdoc function
 * @name fountainInjectApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fountainInjectApp
 */
angular.module('fountainInjectApp')
  .controller('CreateSongCtrl', function ($location, $scope, SongFactory) {
    var vm = this;
    vm.titles = ["Home", "Song"];

    vm.changeRoute = function (path) {
      $location.path($location.path() + path);
    }

    vm.titleName = 'CreateSong';
    vm.hasError = false;
    vm.isDisabledCreate = true;
    /*** add ***/
    //model initial
    vm.newSongTitle = '';
    vm.newSongArtist = '';

    vm.add = function (titleNew, artistNew) {

      console.log('title' + titleNew);
      console.log('artist' + artistNew);

      SongFactory.addSong(titleNew, artistNew);
      vm.changeRoute('songs');
    }

    vm.checkInput = function checkInput(songTitle) {
      // return (songTitle === "" || angular.isUndefined(songTitle)) ? vm.hasError=true :vm.hasError=false;
      if (songTitle === "" || angular.isUndefined(songTitle)) {
        vm.hasError = true;
        vm.isDisabledCreate = true;
      } else {
        vm.hasError = false;
        vm.isDisabledCreate = false;
      }
    }
  })
;

