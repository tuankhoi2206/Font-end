/**
 * Created by vtkhoi on 2/22/2017.
 */
/*
 var breadcrumbs = function( ) {
 return {
 restrict: 'E',
 scope: {
 titles: '=titles'
 },
 controllerAs: 'bcCtrl',
 bindToController: true,
 templateUrl: 'scripts/directive/breadcrumbs.html',
 replace: false
 };
 };
 */

var breadcrumbs = function () {
  return {
  restrict: 'E',
  templateUrl: 'scripts/directive/breadcrumbs.html',
  scope: {
    titles: '=titles'
  },
  controller: BreadCrumbsCtrl,
  controllerAs: 'bc',
  bindToController: true
};
};

BreadCrumbsCtrl.$inject = ['$scope'];

function BreadCrumbsCtrl($scope) {
  var vm = this;
  // vm.titles = $scope.titles;
}
/*
 angular.module('fountainInjectApp')
 .controller('BreadCrumbsCtrl', function () {
 var vm = this;
 vm.titles = [];
 });
 */


angular.module('fountainInjectApp').directive('breadcrumbs', breadcrumbs);
