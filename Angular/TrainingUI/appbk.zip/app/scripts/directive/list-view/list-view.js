/**
 * Created by vtkhoi on 3/3/2017.
 */

var breadcrumbs = function () {
  return {
    restrict: 'E',
    templateUrl: 'scripts/directive/breadcrumbs.html',
    scope: {
      titles: '=titles'
    },
    controller: BreadCrumbsCtrl,
    controllerAs: 'bc',
    bindToController: true
  };
};

BreadCrumbsCtrl.$inject = ['$scope'];

function BreadCrumbsCtrl($scope) {
  var vm = this;
  // vm.titles = $scope.titles;
}
angular.module('fountainInjectApp').directive('breadcrumbs', breadcrumbs);
