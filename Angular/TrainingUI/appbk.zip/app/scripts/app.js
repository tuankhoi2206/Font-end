'use strict';

/**
 * @ngdoc overview
 * @name fountainInjectApp
 * @description
 * # fountainInjectApp
 *
 * Main module of the application.
 */
angular
  .module('fountainInjectApp', [
    // 'ngAnimate',
    // 'ngCookies',
    // 'ngResource',
    'ngRoute'
    // 'ngSanitize',
    // 'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/songPage/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'songs'
      })//song
      .when('/songs', {
        templateUrl: 'views/songPage/songs.html',
        controller: 'SongCtrl',
        controllerAs: 'songs'
      })
      .when('/createsong', {
        templateUrl: 'views/songPage/createsong.html',
        controller: 'CreateSongCtrl',
        controllerAs: 'create'
      })
      .when('/editsong', {
        templateUrl: 'views/songPage/editsong.html',
        controller: 'EditSongCtrl',
        controllerAs: 'edit'
      })// end song
      .when('/playlist', {
        templateUrl: 'views/playlistPage/playlists.html',
        controller: 'PlaylistCtrl',
        controllerAs: 'play'
      })
      .when('/createplaylist', {
        templateUrl: 'views/playlistPage/createplaylist.html',
        controller: 'CreatePlaylistCtrl',
        controllerAs: 'create'
      })
      .when('/editeplaylist', {
        templateUrl: 'views/playlistPage/editplaylist.html',
        controller: 'EditPlaylistCtrl',
        controllerAs: 'editplay'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
