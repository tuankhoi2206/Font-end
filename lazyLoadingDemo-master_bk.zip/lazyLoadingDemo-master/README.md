lazyLoadingDemo
===============

Demo project for AngularJS-il meetup #3.
how to integrate requireJS with AngularJS
to achive lazy loading of angular components after bootstrap.


To run this Demo:
-----------------

1. run bower install
2. run npm install
3. run server.js with (node)
4. point your browser to localhost:8888

#### Link to slides [view slides](https://docs.google.com/presentation/d/1HfenmUwq3_39ZrVGXfkN5XH_x5bzgfF-QgSGcotjSz4/edit?usp=sharing)
#### need support with this demo? [nirkaufman@gmail.com](nirkaufman@gmail.com)
